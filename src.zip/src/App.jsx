import React, { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import LeadForm from '@/components/LeadForm.jsx'
import { 
  Shield, 
  Zap, 
  Eye, 
  Target, 
  Brain, 
  Clock, 
  Search, 
  AlertTriangle,
  CheckCircle,
  ArrowRight,
  Play,
  Users,
  Globe,
  Lock,
  Cpu,
  Activity,
  BarChart3,
  Monitor,
  Phone,
  Mail
} from 'lucide-react'
import HackingAnimation from './components/HackingAnimation.jsx'
import './App.css'

function App() {
  const [currentStat, setCurrentStat] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const [leadOpen, setLeadOpen] = useState(false)

  const stats = [
    { number: "24/7", label: "Monitoreo Continuo", icon: Clock },
    { number: "<0.5%", label: "Falsos Positivos", icon: Target },
    { number: "99.5%", label: "Precisión en Reportes", icon: CheckCircle },
    { number: "20%", label: "Hallazgos de Alto Impacto", icon: AlertTriangle }
  ]

  const services = [
    {
      icon: Target,
      title: "Gestión de Superficie de Ataque",
      subtitle: "JustoHacker prioriza las vulnerabilidades a corregir",
      description: "Mapeo completo de activos externos con priorización inteligente basada en riesgo real."
    },
    {
      icon: Eye,
      title: "Más del 20% de Hallazgos son Impactantes",
      subtitle: "Enfoque en vulnerabilidades que realmente importan",
      description: "A diferencia de los scanners tradicionales, JustoHacker se enfoca en vulnerabilidades con impacto real en tu seguridad."
    },
    {
      icon: Brain,
      title: "IA Avanzada",
      subtitle: "Detección impulsada por inteligencia artificial",
      description: "JustoHacker está impulsado por algoritmos de IA que aprenden de ataques pasados para generar nuevos módulos cuando se encuentran vulnerabilidades."
    }
  ]

  useEffect(() => {
    setIsVisible(true)
    const interval = setInterval(() => {
      setCurrentStat((prev) => (prev + 1) % stats.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-black/90 backdrop-blur-sm border-b border-gray-800">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold">
            <span className="text-white">JUSTO</span>
            <span className="text-primary">HACKER</span>
          </div>
          <div className="hidden md:flex space-x-6">
            <a href="#inicio" className="hover:text-primary transition-colors">Inicio</a>
            <a href="#servicios" className="hover:text-primary transition-colors">Servicios</a>
            <a href="#como-funciona" className="hover:text-primary transition-colors">Cómo Funciona</a>
            <a href="#contacto" className="hover:text-primary transition-colors">Contacto</a>
          </div>
          <div className="flex space-x-4">
            <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white" onClick={() => setLeadOpen(true)}>
              Solicitar Demo
            </Button>
            <Button className="bg-primary hover:bg-primary/90">
              Clientes
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="inicio" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black"></div>
        <div className="absolute inset-0 cyber-grid opacity-20"></div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-2 h-2 bg-primary rounded-full pulse-animation"></div>
        <div className="absolute top-40 right-20 w-3 h-3 bg-accent rounded-full pulse-animation" style={{animationDelay: '1s'}}></div>
        <div className="absolute bottom-40 left-20 w-2 h-2 bg-primary rounded-full pulse-animation" style={{animationDelay: '2s'}}></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="text-center lg:text-left">
              <div className="mb-6">
                <Badge variant="outline" className="border-primary text-primary mb-4">
                  FÁCIL DE USAR • GRATIS PARA PROBAR • SIN TARJETA DE CRÉDITO
                </Badge>
              </div>
              
              <h1 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
                La Plataforma de <span className="text-primary">Ethical Hacking</span> Impulsada por{' '}
                <span className="text-primary">Inteligencia Artificial</span> que{' '}
                <span className="text-white">Nunca Duerme</span>
              </h1>
              
              <p className="text-xl text-gray-300 mb-8 max-w-2xl">
                Protege tus activos digitales las 24 horas, todos los días.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Button size="lg" className="bg-primary hover:bg-primary/90 text-white px-8 py-3">
                  Nuestros Servicios
                </Button>
                <Button size="lg" variant="outline" className="border-gray-600 text-white hover:bg-gray-800 px-8 py-3" onClick={() => setLeadOpen(true)}>
                  Contáctanos
                </Button>
              </div>
            </div>
            
            {/* Right Content - Hacker Image */}
            <div className="relative flex justify-center lg:justify-end">
              <div className="relative">
                {/* Main Image - Smaller size */}
                <img 
                  src="/hacker-hero.png" 
                  alt="Justo Hacker - Ethical Hacker con IA 24/7" 
                  className="relative z-10 w-full max-w-md h-auto object-contain"
                />
              </div>
            </div>
          </div>
          
          {/* Stats Section - one row, smaller cards */}
          <div className="grid grid-cols-4 gap-4 mt-10">
            {stats.map((stat, index) => {
              const Icon = stat.icon
              return (
                <Card key={index} className={`bg-card/30 backdrop-blur-sm border-gray-800 transition-all duration-500 ${
                  currentStat === index ? 'neon-glow scale-105' : ''
                }`}>
                  <CardContent className="p-4 text-center">
                    <Icon className="w-6 h-6 mx-auto mb-2 text-primary" />
                    <div className="text-2xl font-bold text-primary mb-1">{stat.number}</div>
                    <div className="text-xs text-gray-400">{stat.label}</div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="servicios" className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Encuentra y Prioriza tus Vulnerabilidades con{' '}
              <span className="text-primary">&lt;0.5% Falsos Positivos</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Para asegurar tu infraestructura digital, JustoHacker mapea todos tus activos digitales de tu superficie expuesta, los evalúa y te informa qué vulnerabilidades debes corregir primero.
            </p>
          </div>

          {/* Service Cards */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {services.map((service, index) => {
              const Icon = service.icon
              return (
                <Card key={index} className="bg-card/50 backdrop-blur-sm border-gray-800 hover:border-primary/50 transition-all duration-300">
                  <CardHeader>
                    <Icon className="w-12 h-12 text-primary mb-4" />
                    <CardTitle className="text-xl mb-2">{service.title}</CardTitle>
                    <CardDescription className="text-accent font-semibold">
                      {service.subtitle}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-300">{service.description}</p>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          {/* Key Benefits */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Activity className="w-8 h-8 text-primary" />
              </div>
              <h4 className="text-lg font-semibold mb-2">Más de 60,000 hallazgos enviados</h4>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-accent" />
              </div>
              <h4 className="text-lg font-semibold mb-2">Patrones de ataque avanzados con enfoques multi-paso</h4>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-primary" />
              </div>
              <h4 className="text-lg font-semibold mb-2">Detección de nuevas vulnerabilidades impulsada por IA</h4>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-accent" />
              </div>
              <h4 className="text-lg font-semibold mb-2">Aprende de ataques pasados para reducir falsos positivos</h4>
            </div>
          </div>

          <div className="text-center mb-12">
            <p className="text-gray-300 max-w-3xl mx-auto mb-8">
              JustoHacker aprende nuevos vectores de ataque de fuentes open-source y propietarias, así como adiciones manuales de nuestro equipo de I+D.
            </p>
          </div>

          {/* Hacking Animation Demo */}
          <div className="mb-12">
            <div className="text-center mb-8">
              <h3 className="text-3xl font-bold mb-4">
                Visualiza cómo <span className="text-primary">JustoHacker</span> analiza tus sistemas
              </h3>
              <p className="text-gray-300 max-w-2xl mx-auto">
                Observa en tiempo real cómo JustoHacker analiza, detecta y reporta vulnerabilidades en tu infraestructura.
              </p>
            </div>
            <HackingAnimation />
          </div>
        </div>
      </section>

      {/* SOC Section */}
      <section className="py-20 bg-gradient-to-b from-gray-900 to-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              <span className="text-primary">JustoHacker</span> + <span className="text-accent">SOC</span> = <span className="text-white">Respuesta Inmediata</span>
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Nuestro Centro de Operaciones de Seguridad (SOC) monitoreado por expertos humanos analiza cada vulnerabilidad detectada por JustoHacker para alertar en tiempo real a nuestros clientes sobre amenazas críticas y proporcionar respuesta inmediata ante incidentes de seguridad.
            </p>
          </div>

          {/* SOC Animation */}
          <div className="relative bg-gray-800/30 backdrop-blur-sm rounded-lg p-8 border border-gray-700">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-2xl font-bold mb-4 text-primary">SOC 24/7 Activo</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse"></div>
                    <span className="text-gray-300">Analistas de seguridad monitoreando</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div>
                    <span className="text-gray-300">Correlación de eventos en tiempo real</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full animate-pulse"></div>
                    <span className="text-gray-300">Respuesta inmediata a incidentes</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                    <span className="text-gray-300">Alertas críticas instantáneas</span>
                  </div>
                </div>
              </div>
              <div className="relative">
                <div className="w-full h-64 bg-gray-900/50 rounded-lg border border-gray-600 flex items-center justify-center">
                  <div className="text-center">
                    <Monitor className="w-16 h-16 text-primary mx-auto mb-4" />
                    <div className="text-2xl font-bold text-primary mb-2">SOC ACTIVO</div>
                    <div className="text-sm text-gray-400">Centro de Operaciones de Seguridad</div>
                    <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <div className="text-accent font-bold">24/7</div>
                        <div className="text-gray-400">Monitoreo</div>
                      </div>
                      <div>
                        <div className="text-green-500 font-bold">ACTIVO</div>
                        <div className="text-gray-400">Estado</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-20 bg-gradient-to-b from-gray-900 to-black">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Protege tus Activos Digitales <span className="text-primary">24/7</span>
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            La seguridad de tu organización no puede esperar. Nuestra IA trabaja 24/7 para mantener 
            tus sistemas protegidos contra las amenazas más avanzadas.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-primary hover:bg-primary/90 text-white px-8 py-3" onClick={() => setLeadOpen(true)}>
              Solicitar Demostración
            </Button>
            <Button size="lg" variant="outline" className="border-accent text-accent hover:bg-accent hover:text-black px-8 py-3">
              Escaneo Gratuito
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black border-t border-gray-800 py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="text-2xl font-bold mb-4">
                <span className="text-white">JUSTO</span>
                <span className="text-primary">HACKER</span>
              </div>
              <p className="text-gray-400 mb-4">
                La plataforma de ethical hacking impulsada por IA que nunca duerme.
              </p>
              <div className="space-y-2">
                <div className="flex items-center space-x-2 text-gray-400">
                  <Phone className="w-4 h-4" />
                  <span>+56 2 326 30660</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-400">
                  <Mail className="w-4 h-4" />
                  <span>contacto@justohacker.com</span>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Servicios</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Pentesting Automatizado</li>
                <li>Monitoreo 24/7</li>
                <li>Gestión de Vulnerabilidades</li>
                <li>Reportes Inteligentes</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Empresa</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Acerca de</li>
                <li>Equipo</li>
                <li>Carreras</li>
                <li>Contacto</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Recursos</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Documentación</li>
                <li>Blog</li>
                <li>Casos de Estudio</li>
                <li>Soporte</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Justo Hacker. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>

      {/* Lead Form Modal */}
      <LeadForm open={leadOpen} onOpenChange={setLeadOpen} />
    </div>
  )
}

export default App

