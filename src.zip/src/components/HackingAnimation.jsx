import React, { useState, useEffect } from 'react'
import { Shield, Zap, AlertTriangle, CheckCircle, Eye, Target } from 'lucide-react'

const HackingAnimation = () => {
  const [currentStep, setCurrentStep] = useState(0)
  const [scanningText, setScanningText] = useState('')
  const [vulnerabilities, setVulnerabilities] = useState([])
  const [isScanning, setIsScanning] = useState(true)

  const hackingSteps = [
    { 
      title: "Reconocimiento", 
      description: "Escaneando puertos y servicios...",
      icon: Eye,
      color: "text-accent"
    },
    { 
      title: "Enumeración", 
      description: "Identificando versiones y tecnologías...",
      icon: Target,
      color: "text-primary"
    },
    { 
      title: "Análisis", 
      description: "Buscando vulnerabilidades conocidas...",
      icon: AlertTriangle,
      color: "text-yellow-500"
    },
    { 
      title: "Explotación", 
      description: "Probando vectores de ataque...",
      icon: Zap,
      color: "text-red-500"
    },
    { 
      title: "Reporte", 
      description: "Generando informe de seguridad...",
      icon: CheckCircle,
      color: "text-green-500"
    }
  ]

  const vulnerabilityTypes = [
    "SQL Injection detectada en /login.php",
    "XSS reflejado en parámetro 'search'",
    "Directorio sin autenticación: /admin",
    "Versión vulnerable de Apache 2.4.29",
    "Puerto SSH con autenticación débil",
    "Certificado SSL expirado",
    "Información sensible en robots.txt",
    "CSRF en formulario de contacto"
  ]

  const scanningTexts = [
    "Escaneando 192.168.1.1...",
    "Puerto 80/tcp abierto",
    "Puerto 443/tcp abierto", 
    "Puerto 22/tcp abierto",
    "Detectando servicios...",
    "Apache/2.4.29 identificado",
    "MySQL 5.7.33 detectado",
    "Analizando vulnerabilidades...",
    "CVE-2021-44228 encontrado",
    "Generando reporte..."
  ]

  useEffect(() => {
    const stepInterval = setInterval(() => {
      setCurrentStep((prev) => (prev + 1) % hackingSteps.length)
    }, 3000)

    const textInterval = setInterval(() => {
      setScanningText(scanningTexts[Math.floor(Math.random() * scanningTexts.length)])
    }, 800)

    const vulnInterval = setInterval(() => {
      if (vulnerabilities.length < 4) {
        const newVuln = vulnerabilityTypes[Math.floor(Math.random() * vulnerabilityTypes.length)]
        if (!vulnerabilities.includes(newVuln)) {
          setVulnerabilities(prev => [...prev, newVuln])
        }
      }
    }, 2000)

    return () => {
      clearInterval(stepInterval)
      clearInterval(textInterval)
      clearInterval(vulnInterval)
    }
  }, [vulnerabilities])

  const currentStepData = hackingSteps[currentStep]
  const StepIcon = currentStepData.icon

  return (
    <div className="relative w-full max-w-4xl mx-auto p-6 bg-black/90 rounded-lg border border-gray-800 overflow-hidden">
      {/* Background Matrix Effect */}
      <div className="absolute inset-0 opacity-10">
        <div className="cyber-grid h-full w-full"></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-green-500 rounded-full pulse-animation"></div>
            <span className="text-green-500 font-mono text-sm">JUSTO HACKER IA - ACTIVO</span>
          </div>
          <div className="text-primary font-mono text-sm">
            {new Date().toLocaleTimeString()}
          </div>
        </div>

        {/* Current Step Display */}
        <div className="mb-8">
          <div className="flex items-center space-x-4 mb-4">
            <div className={`w-12 h-12 rounded-full bg-gray-800 flex items-center justify-center ${currentStepData.color}`}>
              <StepIcon className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">{currentStepData.title}</h3>
              <p className="text-gray-400">{currentStepData.description}</p>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="w-full bg-gray-800 rounded-full h-2 mb-4">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-1000 ease-out"
              style={{ width: `${((currentStep + 1) / hackingSteps.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Terminal Output */}
        <div className="bg-gray-900 rounded-lg p-4 mb-6 font-mono text-sm">
          <div className="flex items-center mb-2">
            <span className="text-green-500">root@justohacker:~$</span>
            <span className="text-white ml-2 typing-animation">{scanningText}</span>
          </div>
          <div className="space-y-1 text-gray-300">
            <div className="text-accent">Starting Nmap 7.94 ( https://nmap.org )</div>
            <div className="text-white">Nmap scan report for target.example.com</div>
            <div className="text-green-500">Host is up (0.0012s latency).</div>
            <div className="text-yellow-500">PORT     STATE SERVICE VERSION</div>
            <div className="text-white">22/tcp   open  ssh     OpenSSH 7.4</div>
            <div className="text-white">80/tcp   open  http    Apache httpd 2.4.29</div>
            <div className="text-white">443/tcp  open  https   Apache httpd 2.4.29</div>
          </div>
        </div>

        {/* Vulnerabilities Found */}
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <h4 className="text-lg font-semibold text-white mb-3 flex items-center">
              <AlertTriangle className="w-5 h-5 text-red-500 mr-2" />
              Vulnerabilidades Detectadas
            </h4>
            <div className="space-y-2">
              {vulnerabilities.map((vuln, index) => (
                <div 
                  key={index}
                  className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 text-sm animate-pulse"
                >
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                    <span className="text-red-400">{vuln}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-white mb-3 flex items-center">
              <Shield className="w-5 h-5 text-green-500 mr-2" />
              Estadísticas en Tiempo Real
            </h4>
            <div className="space-y-3">
              <div className="bg-gray-800 rounded-lg p-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Puertos Escaneados</span>
                  <span className="text-accent font-bold">65,535</span>
                </div>
              </div>
              <div className="bg-gray-800 rounded-lg p-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Servicios Detectados</span>
                  <span className="text-primary font-bold">{Math.floor(Math.random() * 20) + 5}</span>
                </div>
              </div>
              <div className="bg-gray-800 rounded-lg p-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Vulnerabilidades</span>
                  <span className="text-red-500 font-bold">{vulnerabilities.length}</span>
                </div>
              </div>
              <div className="bg-gray-800 rounded-lg p-3">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Precisión</span>
                  <span className="text-green-500 font-bold">99.5%</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Step Indicators */}
        <div className="flex justify-center space-x-4 mt-8">
          {hackingSteps.map((step, index) => {
            const Icon = step.icon
            return (
              <div 
                key={index}
                className={`flex flex-col items-center space-y-2 transition-all duration-300 ${
                  index === currentStep ? 'scale-110' : 'opacity-50'
                }`}
              >
                <div className={`w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center ${
                  index === currentStep ? step.color : 'text-gray-500'
                }`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-xs text-gray-400">{step.title}</span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

export default HackingAnimation

